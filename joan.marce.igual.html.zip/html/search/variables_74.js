var searchData=
[
  ['tamany',['tamany',['../class_conjunt_org.html#a468e7686498561628ad731ea196df8b5',1,'ConjuntOrg::tamany()'],['../class_organisme.html#a5d30992b5ded1a9314aff94ce9fb3932',1,'Organisme::tamany()'],['../class_ranking.html#a3001b3854a474fc12c0fc31e0baea946',1,'Ranking::tamany()']]]
];
