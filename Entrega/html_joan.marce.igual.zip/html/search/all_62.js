var searchData=
[
  ['busca_5factiva_5fgran',['busca_activa_gran',['../class_organisme.html#a408fc304405eb3e02c009a27b0b2668f',1,'Organisme']]],
  ['busca_5factiva_5fpetit',['busca_activa_petit',['../class_organisme.html#a815da683b5c2992556137a8fc51a0ec7',1,'Organisme']]],
  ['busca_5fmax',['busca_max',['../class_organisme.html#a380d8211806260b37a6692003b1d332e',1,'Organisme']]]
];
