var searchData=
[
  ['afegir_5ffill',['afegir_fill',['../class_ranking.html#a15715ea90e6caf702490fd329bf5ec70',1,'Ranking']]]
];
