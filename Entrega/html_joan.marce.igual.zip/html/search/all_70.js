var searchData=
[
  ['pr_c3_a0ctica_20de_20pro2_3a_20reproducci_c3_b3_20al_20laboratori',['Pràctica de PRO2: Reproducció al laboratori',['../index.html',1,'']]],
  ['parella',['parella',['../struct_ranking_1_1_par_fill.html#a73b7b596d987abbf7f27026317b5a85c',1,'Ranking::ParFill']]],
  ['parfill',['ParFill',['../struct_ranking_1_1_par_fill.html',1,'Ranking']]],
  ['pro2_2ecpp',['pro2.cpp',['../pro2_8cpp.html',1,'']]]
];
