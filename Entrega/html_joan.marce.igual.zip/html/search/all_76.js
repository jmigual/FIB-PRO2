var searchData=
[
  ['v',['V',['../class_conjunt_org.html#adab11e0ac8295072ec682716478a535a',1,'ConjuntOrg']]],
  ['vius',['vius',['../class_conjunt_org.html#a00b8f17975cd3c5f4f51e049bf19b8a2',1,'ConjuntOrg']]]
];
