var searchData=
[
  ['llegir',['llegir',['../class_conjunt_org.html#a93418ffaeff18413ab9681f2d8716129',1,'ConjuntOrg']]],
  ['llegir_5forganisme',['llegir_organisme',['../class_organisme.html#a23aa1d52f494c77fc007e1dff1432b4b',1,'Organisme']]],
  ['llegir_5frec',['llegir_rec',['../class_organisme.html#a472dfd280eeb8b044e377f6256d2a6e2',1,'Organisme']]]
];
