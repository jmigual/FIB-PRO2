var searchData=
[
  ['a_5fbuit',['a_buit',['../class_arbre.html#aa74ec0d2b601487b822eb70100330582',1,'Arbre']]],
  ['activa',['activa',['../struct_organisme_1_1_celula.html#ae76b8fe2263311c1a52e4fba8f649114',1,'Organisme::Celula']]],
  ['afegir_5ffill',['afegir_fill',['../class_ranking.html#a15715ea90e6caf702490fd329bf5ec70',1,'Ranking']]],
  ['aparellat',['Aparellat',['../class_conjunt_org.html#a9782fdb4c89e8dd61762453de8f77fcb',1,'ConjuntOrg']]],
  ['arbre',['Arbre',['../class_arbre.html',1,'Arbre&lt; T &gt;'],['../class_arbre.html#a3f613426983169266297eb841996845e',1,'Arbre::Arbre()'],['../class_arbre.html#a8f8615c19988334f9b77dc51f44acc6d',1,'Arbre::Arbre(const Arbre &amp;original)']]],
  ['arbre_2ehpp',['Arbre.hpp',['../_arbre_8hpp.html',1,'']]],
  ['arbre_3c_20organisme_3a_3acelula_20_3e',['Arbre&lt; Organisme::Celula &gt;',['../class_arbre.html',1,'']]],
  ['arrel',['arrel',['../class_arbre.html#aa6e2559ead7dfceda962cff11fb1a15c',1,'Arbre']]]
];
