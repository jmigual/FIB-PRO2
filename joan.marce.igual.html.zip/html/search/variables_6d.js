var searchData=
[
  ['max_5fid',['max_id',['../class_organisme.html#ae7f51a74f01cee155cf88a5b01545f78',1,'Organisme']]],
  ['mensaje',['mensaje',['../class_p_r_o2_excepcio.html#aa82c5df8e191f4b6134cd85d270a9e87',1,'PRO2Excepcio']]],
  ['mort',['mort',['../class_organisme.html#ae20564db8d9ba5b7547750375010ed7b',1,'Organisme']]]
];
