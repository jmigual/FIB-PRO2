var searchData=
[
  ['parella',['parella',['../struct_ranking_1_1_par_fill.html#a73b7b596d987abbf7f27026317b5a85c',1,'Ranking::ParFill']]]
];
