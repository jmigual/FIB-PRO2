var searchData=
[
  ['llegir',['llegir',['../class_conjunt_org.html#aa933556b09efa171f23abed943fe78a7',1,'ConjuntOrg']]],
  ['llegir_5forganisme',['llegir_organisme',['../class_organisme.html#a056a9402130c7081b608838ba9ef2a30',1,'Organisme']]]
];
