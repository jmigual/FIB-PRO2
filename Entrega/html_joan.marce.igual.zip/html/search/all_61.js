var searchData=
[
  ['activa',['activa',['../struct_organisme_1_1_celula.html#ae76b8fe2263311c1a52e4fba8f649114',1,'Organisme::Celula']]],
  ['afegir_5ffill',['afegir_fill',['../class_ranking.html#a15715ea90e6caf702490fd329bf5ec70',1,'Ranking']]],
  ['aparellat',['Aparellat',['../class_conjunt_org.html#a9782fdb4c89e8dd61762453de8f77fcb',1,'ConjuntOrg']]]
];
