var searchData=
[
  ['compatibles',['compatibles',['../class_organisme.html#a4706d097ab7348c9161cc8f8a5052418',1,'Organisme']]],
  ['conjuntorg',['ConjuntOrg',['../class_conjunt_org.html#a573205d24e669356dc44462a6ef95d71',1,'ConjuntOrg::ConjuntOrg(int M)'],['../class_conjunt_org.html#a4a0c1fe0378f0564295dcaa5e7d9bde2',1,'ConjuntOrg::ConjuntOrg(const ConjuntOrg &amp;C)']]],
  ['consultar_5ftamany',['consultar_tamany',['../class_conjunt_org.html#adbce2716cb543fa4d513c6d2a21b4fe1',1,'ConjuntOrg::consultar_tamany()'],['../class_organisme.html#a2232a1a2596db03697e6345fff587621',1,'Organisme::consultar_tamany()']]],
  ['copia_5fnode_5farbre',['copia_node_arbre',['../class_arbre.html#a8562c3574c0037eae30a6d04050fb517',1,'Arbre']]]
];
