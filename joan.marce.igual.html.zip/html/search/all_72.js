var searchData=
[
  ['rank',['Rank',['../class_ranking.html#a23ba29c13cb5ac32d3fc97252f20afde',1,'Ranking']]],
  ['ranking',['Ranking',['../class_ranking.html',1,'Ranking'],['../class_ranking.html#a2cb68818448b64432f2da6c7f3cfb446',1,'Ranking::ranking() const '],['../class_ranking.html#af700e3f1e24eb35173adff4fbcac7c68',1,'Ranking::Ranking(int M)']]],
  ['ranking_2ehpp',['Ranking.hpp',['../_ranking_8hpp.html',1,'']]],
  ['readbool',['readbool',['../utils_8_p_r_o2.html#a56691e176645da552c107ef124ad701a',1,'utils.PRO2']]],
  ['readchar',['readchar',['../utils_8_p_r_o2.html#a831a2329c820ba9b9b378131ed143ff5',1,'utils.PRO2']]],
  ['readdouble',['readdouble',['../utils_8_p_r_o2.html#a2379d4429b4e913e714a3c889061c61c',1,'utils.PRO2']]],
  ['readint',['readint',['../utils_8_p_r_o2.html#a49000a716e38017061f71cbefe697a9c',1,'utils.PRO2']]],
  ['readstring',['readstring',['../utils_8_p_r_o2.html#a0785c313e983db73f256ae0ccf34591c',1,'utils.PRO2']]],
  ['rel',['Rel',['../class_ranking.html#a714b5b8881dccd99dad7e58b81ce7769',1,'Ranking']]],
  ['reproduir',['reproduir',['../class_conjunt_org.html#a5487cfb897f2a594d150f41774b53547',1,'ConjuntOrg']]],
  ['reproduir_5forganisme',['reproduir_organisme',['../class_organisme.html#ad2f37457376d9686751e69d45607731b',1,'Organisme']]],
  ['retallar',['retallar',['../class_conjunt_org.html#a2ed57a61b109254526a28b6ec1944d2f',1,'ConjuntOrg']]],
  ['retallar_5forganisme',['retallar_organisme',['../class_organisme.html#a3db36c1cb9d93f2750fd033b137dc702',1,'Organisme']]],
  ['retallar_5frecursiu',['retallar_recursiu',['../class_organisme.html#a8207d029746a3dd457ae7d08d392ad71',1,'Organisme']]],
  ['retallat',['retallat',['../class_organisme.html#acf912225a83570cb68542dcc6709023a',1,'Organisme']]]
];
