var searchData=
[
  ['intersec_5frecursiu',['intersec_recursiu',['../class_organisme.html#add0b533b80fa284326cef38f1de3420b',1,'Organisme']]]
];
