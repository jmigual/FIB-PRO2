var searchData=
[
  ['es_5fbuit',['es_buit',['../class_arbre.html#a68a51f6689f0b2889e8e1d56266fd620',1,'Arbre']]],
  ['es_5fmort',['es_mort',['../class_organisme.html#abe3c4923cc5641e48724312bc298c8a9',1,'Organisme']]],
  ['esborra_5fnode_5farbre',['esborra_node_arbre',['../class_arbre.html#ab97c98d266a5b8973fe2519c14cf362a',1,'Arbre']]],
  ['escriure_5forganisme',['escriure_organisme',['../class_organisme.html#ab359a3109ec7ff96018bbe08d97043cf',1,'Organisme']]],
  ['escriure_5fultims',['escriure_ultims',['../class_conjunt_org.html#ae14165ea78d2707b8c80d1ccf7c2cf41',1,'ConjuntOrg']]],
  ['estat',['estat',['../class_conjunt_org.html#a0c57d7702a556a7e9fe1a819414845a7',1,'ConjuntOrg']]],
  ['estirar',['estirar',['../class_conjunt_org.html#aed52193459bacdfe3db143809beb5a0f',1,'ConjuntOrg']]],
  ['estirar_5forganisme',['estirar_organisme',['../class_organisme.html#a41a2ea17f4287dc3d00a45476a602309',1,'Organisme']]],
  ['estirar_5frecursiu',['estirar_recursiu',['../class_organisme.html#a8dbc9127169717373507ddac7a9c7df9',1,'Organisme']]]
];
