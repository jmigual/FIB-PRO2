var searchData=
[
  ['marca',['MARCA',['../main_8cpp.html#a41985a541fe6a11a9efbe1c57619c004',1,'main.cpp']]]
];
