var searchData=
[
  ['main',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]],
  ['marca',['MARCA',['../main_8cpp.html#a41985a541fe6a11a9efbe1c57619c004',1,'main.cpp']]],
  ['max_5fid',['max_id',['../class_organisme.html#ae7f51a74f01cee155cf88a5b01545f78',1,'Organisme']]],
  ['mensaje',['mensaje',['../class_p_r_o2_excepcio.html#aa82c5df8e191f4b6134cd85d270a9e87',1,'PRO2Excepcio']]],
  ['mort',['mort',['../class_organisme.html#ae20564db8d9ba5b7547750375010ed7b',1,'Organisme']]],
  ['morts',['morts',['../class_conjunt_org.html#aa250202ccc4d06ead8b11c9b26c2f28d',1,'ConjuntOrg']]]
];
