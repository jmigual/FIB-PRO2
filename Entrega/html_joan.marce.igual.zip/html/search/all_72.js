var searchData=
[
  ['rank',['Rank',['../class_ranking.html#a23ba29c13cb5ac32d3fc97252f20afde',1,'Ranking']]],
  ['ranking',['Ranking',['../class_ranking.html',1,'Ranking'],['../class_ranking.html#a15530212fa43df377a0db7c14c0f918a',1,'Ranking::ranking()'],['../class_ranking.html#a1ae3c692e235d84c62537c1bb93ee9fe',1,'Ranking::Ranking(int M, int n)']]],
  ['ranking_2ecpp',['Ranking.cpp',['../_ranking_8cpp.html',1,'']]],
  ['ranking_2ehpp',['Ranking.hpp',['../_ranking_8hpp.html',1,'']]],
  ['rel',['Rel',['../class_ranking.html#a714b5b8881dccd99dad7e58b81ce7769',1,'Ranking']]],
  ['reproduir',['reproduir',['../class_conjunt_org.html#a5487cfb897f2a594d150f41774b53547',1,'ConjuntOrg::reproduir()'],['../class_organisme.html#a432a936caea5cd11c936f957113512ff',1,'Organisme::reproduir()']]],
  ['reproduir_5forganisme',['reproduir_organisme',['../class_organisme.html#af14aa2137d0ecc78c65e39104d1df56b',1,'Organisme']]],
  ['retallar',['retallar',['../class_conjunt_org.html#a2ed57a61b109254526a28b6ec1944d2f',1,'ConjuntOrg']]],
  ['retallar_5forganisme',['retallar_organisme',['../class_organisme.html#a3db36c1cb9d93f2750fd033b137dc702',1,'Organisme']]],
  ['retallar_5frecursiu',['retallar_recursiu',['../class_organisme.html#afcf378649f70825d45470c7944788b30',1,'Organisme']]],
  ['retallat',['retallat',['../class_organisme.html#acf912225a83570cb68542dcc6709023a',1,'Organisme']]]
];
