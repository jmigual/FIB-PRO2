var searchData=
[
  ['main',['main',['../pro2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2.cpp']]],
  ['morts',['morts',['../class_conjunt_org.html#aa250202ccc4d06ead8b11c9b26c2f28d',1,'ConjuntOrg']]]
];
