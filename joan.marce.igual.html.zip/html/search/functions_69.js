var searchData=
[
  ['intersec_5frecursiu',['intersec_recursiu',['../class_organisme.html#a2de37bf3c73820ecdb25f2e0cb8339d7',1,'Organisme']]]
];
