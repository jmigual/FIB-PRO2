var searchData=
[
  ['marca',['MARCA',['../pro2_8cpp.html#a41985a541fe6a11a9efbe1c57619c004',1,'pro2.cpp']]],
  ['marca_5forg',['MARCA_ORG',['../pro2_8cpp.html#a3ab5f0d6ed6b53d125a5c20e077a791f',1,'pro2.cpp']]]
];
